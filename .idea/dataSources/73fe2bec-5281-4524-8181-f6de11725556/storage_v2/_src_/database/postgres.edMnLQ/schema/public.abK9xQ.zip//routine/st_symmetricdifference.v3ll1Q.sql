create function st_symmetricdifference(geom1 ngpt.geometry, geom2 ngpt.geometry) returns ngpt.geometry
    language sql
as
$$
SELECT ST_SymDifference(geom1, geom2, -1.0);
$$;

alter function st_symmetricdifference(ngpt.geometry, ngpt.geometry) owner to postgres;

