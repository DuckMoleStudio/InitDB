create function st_intersection(ngpt.geography, ngpt.geography) returns ngpt.geography
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ngpt.geography(ngpt.ST_Transform(ngpt.ST_Intersection(ngpt.ST_Transform(ngpt.geometry($1), ngpt._ST_BestSRID($1, $2)), ngpt.ST_Transform(ngpt.geometry($2), ngpt._ST_BestSRID($1, $2))), 4326))
$$;

comment on function st_intersection(ngpt.geography, ngpt.geography) is 'args: geogA, geogB - Returns a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(ngpt.geography, ngpt.geography) owner to postgres;

