create function st_pointfromtext(text) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT CASE WHEN ngpt.geometrytype(ngpt.ST_GeomFromText($1)) = 'POINT'
	THEN ngpt.ST_GeomFromText($1)
	ELSE NULL END
$$;

alter function st_pointfromtext(text) owner to postgres;

