create function st_mlinefromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT CASE WHEN ngpt.geometrytype(ngpt.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN ngpt.ST_GeomFromText($1)
	ELSE NULL END

$$;

alter function st_mlinefromtext(text) owner to postgres;

