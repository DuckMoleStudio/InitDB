create function _st_concavehull(param_inputgeom ngpt.geometry) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 10000
    language plpgsql
as
$$
DECLARE
	vexhull ngpt.geometry;
	var_resultgeom ngpt.geometry;
	var_inputgeom ngpt.geometry;
	vexring ngpt.geometry;
	cavering ngpt.geometry;
	cavept ngpt.geometry[];
	seglength double precision;
	var_tempgeom ngpt.geometry;
	scale_factor float := 1;
	i integer;
	BEGIN
		-- First compute the ConvexHull of the geometry
		vexhull := ngpt.ST_ConvexHull(param_inputgeom);
		var_inputgeom := param_inputgeom;
		--A point really has no concave hull
		IF ngpt.ST_GeometryType(vexhull) = 'ST_Point' OR ngpt.ST_GeometryType(vexHull) = 'ST_LineString' THEN
			RETURN vexhull;
		END IF;

		-- convert the hull perimeter to a linestring so we can manipulate individual points
		vexring := CASE WHEN ngpt.ST_GeometryType(vexhull) = 'ST_LineString' THEN vexhull ELSE ngpt.ST_ExteriorRing(vexhull) END;
		IF abs(ngpt.ST_X(ngpt.ST_PointN(vexring,1))) < 1 THEN --scale the geometry to prevent stupid precision errors - not sure it works so make low for now
			scale_factor := 100;
			vexring := ngpt.ST_Scale(vexring, scale_factor,scale_factor);
			var_inputgeom := ngpt.ST_Scale(var_inputgeom, scale_factor, scale_factor);
			--RAISE NOTICE 'Scaling';
		END IF;
		seglength := ngpt.ST_Length(vexring)/least(ngpt.ST_NPoints(vexring)*2,1000) ;

		vexring := ngpt.ST_Segmentize(vexring, seglength);
		-- find the point on the original geom that is closest to each point of the convex hull and make a new linestring out of it.
		cavering := ngpt.ST_Collect(
			ARRAY(

				SELECT
					ngpt.ST_ClosestPoint(var_inputgeom, pt ) As the_geom
					FROM (
						SELECT  ngpt.ST_PointN(vexring, n ) As pt, n
							FROM
							generate_series(1, ngpt.ST_NPoints(vexring) ) As n
						) As pt

				)
			)
		;

		var_resultgeom := ngpt.ST_MakeLine(geom)
			FROM ngpt.ST_Dump(cavering) As foo;

		IF ngpt.ST_IsSimple(var_resultgeom) THEN
			var_resultgeom := ngpt.ST_MakePolygon(var_resultgeom);
			--RAISE NOTICE 'is Simple: %', var_resultgeom;
		ELSE 
			--RAISE NOTICE 'is not Simple: %', var_resultgeom;
			var_resultgeom := ngpt.ST_ConvexHull(var_resultgeom);
		END IF;

		IF scale_factor > 1 THEN -- scale the result back
			var_resultgeom := ngpt.ST_Scale(var_resultgeom, 1/scale_factor, 1/scale_factor);
		END IF;

		-- make sure result covers original (#3638)
		-- Using ST_UnaryUnion since SFCGAL doesn't replace with its own implementation
		-- and SFCGAL one chokes for some reason
		var_resultgeom := ngpt.ST_UnaryUnion(ngpt.ST_Collect(param_inputgeom, var_resultgeom) );
		RETURN var_resultgeom;

	END;
$$;

alter function _st_concavehull(ngpt.geometry) owner to postgres;

