create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ngpt.ST_Distance($1::ngpt.geometry, $2::ngpt.geometry);
$$;

alter function st_distance(text, text) owner to postgres;

