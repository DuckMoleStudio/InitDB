create function st_buffer(ngpt.geography, double precision, integer) returns ngpt.geography
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ngpt.geography(ngpt.ST_Transform(ngpt.ST_Buffer(ngpt.ST_Transform(ngpt.geometry($1), ngpt._ST_BestSRID($1)), $2, $3), 4326))
$$;

comment on function st_buffer(ngpt.geography, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - Returns a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(ngpt.geography, double precision, integer) owner to postgres;

