create function st_intersection(text, text) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT ngpt.ST_Intersection($1::ngpt.geometry, $2::ngpt.geometry);
$$;

alter function st_intersection(text, text) owner to postgres;

