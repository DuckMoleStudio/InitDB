create function st_longestline(geom1 ngpt.geometry, geom2 ngpt.geometry) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT ngpt._ST_LongestLine(ngpt.ST_ConvexHull($1), ngpt.ST_ConvexHull($2))
$$;

comment on function st_longestline(ngpt.geometry, ngpt.geometry) is 'args: g1, g2 - Returns the 2D longest line between two geometries.';

alter function st_longestline(ngpt.geometry, ngpt.geometry) owner to postgres;

