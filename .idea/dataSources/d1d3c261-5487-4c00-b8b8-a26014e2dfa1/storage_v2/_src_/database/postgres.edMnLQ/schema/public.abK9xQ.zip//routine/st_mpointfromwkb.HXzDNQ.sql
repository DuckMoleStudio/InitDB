create function st_mpointfromwkb(bytea, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
SELECT CASE WHEN ngpt.geometrytype(ngpt.ST_GeomFromWKB($1, $2)) = 'MULTIPOINT'
	THEN ngpt.ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

alter function st_mpointfromwkb(bytea, integer) owner to postgres;

