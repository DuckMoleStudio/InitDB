create function st_astext(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_AsText($1::ngpt.geometry);
$$;

alter function st_astext(text) owner to postgres;

