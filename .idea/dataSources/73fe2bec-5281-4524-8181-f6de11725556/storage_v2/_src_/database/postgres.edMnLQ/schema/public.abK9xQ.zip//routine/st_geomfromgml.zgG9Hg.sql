create function st_geomfromgml(text) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt._ST_GeomFromGML($1, 0)
$$;

alter function st_geomfromgml(text) owner to postgres;

