create function _st_dwithinuncached(ngpt.geography, ngpt.geography, double precision) returns boolean
    immutable
    language sql
as
$$
SELECT $1 OPERATOR(ngpt.&&) ngpt._ST_Expand($2,$3) AND $2 OPERATOR(ngpt.&&) ngpt._ST_Expand($1,$3) AND ngpt._ST_DWithinUnCached($1, $2, $3, true)
$$;

alter function _st_dwithinuncached(ngpt.geography, ngpt.geography, double precision) owner to postgres;

