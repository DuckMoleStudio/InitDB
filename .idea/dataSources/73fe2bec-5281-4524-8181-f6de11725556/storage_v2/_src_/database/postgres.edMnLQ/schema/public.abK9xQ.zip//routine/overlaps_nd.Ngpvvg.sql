create function overlaps_nd(ngpt.geometry, ngpt.gidx) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
SELECT $2 OPERATOR(ngpt.&&&) $1;
$$;

alter function overlaps_nd(ngpt.geometry, ngpt.gidx) owner to postgres;

