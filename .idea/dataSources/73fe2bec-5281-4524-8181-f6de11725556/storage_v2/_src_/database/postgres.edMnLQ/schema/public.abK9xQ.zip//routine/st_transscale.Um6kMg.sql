create function st_transscale(ngpt.geometry, double precision, double precision, double precision, double precision) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
SELECT ngpt.ST_Affine($1,  $4, 0, 0,  0, $5, 0,
		0, 0, 1,  $2 * $4, $3 * $5, 0)
$$;

comment on function st_transscale(ngpt.geometry, double precision, double precision, double precision, double precision) is 'args: geomA, deltaX, deltaY, XFactor, YFactor - Translates and scales a geometry by given offsets and factors.';

alter function st_transscale(ngpt.geometry, double precision, double precision, double precision, double precision) owner to postgres;

