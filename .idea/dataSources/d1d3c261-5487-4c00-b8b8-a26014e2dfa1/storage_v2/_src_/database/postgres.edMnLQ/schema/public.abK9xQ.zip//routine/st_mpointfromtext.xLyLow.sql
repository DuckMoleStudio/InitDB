create function st_mpointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT CASE WHEN ngpt.geometrytype(ngpt.ST_GeomFromText($1)) = 'MULTIPOINT'
	THEN ngpt.ST_GeomFromText($1)
	ELSE NULL END

$$;

alter function st_mpointfromtext(text) owner to postgres;

