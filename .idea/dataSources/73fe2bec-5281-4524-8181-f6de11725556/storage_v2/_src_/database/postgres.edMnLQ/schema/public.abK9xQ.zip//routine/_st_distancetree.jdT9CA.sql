create function _st_distancetree(ngpt.geography, ngpt.geography) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT ngpt._ST_DistanceTree($1, $2, 0.0, true)
$$;

alter function _st_distancetree(ngpt.geography, ngpt.geography) owner to postgres;

