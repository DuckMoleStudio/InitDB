create function _st_distanceuncached(ngpt.geography, ngpt.geography, boolean) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT ngpt._ST_DistanceUnCached($1, $2, 0.0, $3)
$$;

alter function _st_distanceuncached(ngpt.geography, ngpt.geography, boolean) owner to postgres;

