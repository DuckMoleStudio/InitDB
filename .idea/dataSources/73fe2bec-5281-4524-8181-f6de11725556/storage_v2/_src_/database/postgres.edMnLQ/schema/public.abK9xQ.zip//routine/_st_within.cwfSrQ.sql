create function _st_within(geom1 ngpt.geometry, geom2 ngpt.geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT ngpt._ST_Contains($2,$1)
$$;

alter function _st_within(ngpt.geometry, ngpt.geometry) owner to postgres;

