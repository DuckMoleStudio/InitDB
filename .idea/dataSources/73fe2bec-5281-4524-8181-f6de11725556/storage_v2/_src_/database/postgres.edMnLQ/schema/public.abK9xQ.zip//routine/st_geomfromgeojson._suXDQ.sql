create function st_geomfromgeojson(jsonb) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_GeomFromGeoJson($1::text)
$$;

alter function st_geomfromgeojson(jsonb) owner to postgres;

