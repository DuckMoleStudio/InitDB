create function st_polygonfromtext(text) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_PolyFromText($1)
$$;

alter function st_polygonfromtext(text) owner to postgres;

