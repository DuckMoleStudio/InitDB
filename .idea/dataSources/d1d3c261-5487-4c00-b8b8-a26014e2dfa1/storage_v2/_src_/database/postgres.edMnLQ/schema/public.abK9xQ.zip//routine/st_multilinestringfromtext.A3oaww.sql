create function st_multilinestringfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_MLineFromText($1)
$$;

alter function st_multilinestringfromtext(text) owner to postgres;

