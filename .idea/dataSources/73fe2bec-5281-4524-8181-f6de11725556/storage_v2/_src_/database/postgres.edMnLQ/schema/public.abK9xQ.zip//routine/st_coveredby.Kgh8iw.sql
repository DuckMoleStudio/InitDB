create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT ngpt.ST_CoveredBy($1::ngpt.geometry, $2::ngpt.geometry);
$$;

alter function st_coveredby(text, text) owner to postgres;

