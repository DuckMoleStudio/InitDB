create function st_centroid(text) returns ngpt.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ngpt.ST_Centroid($1::ngpt.geometry);
$$;

alter function st_centroid(text) owner to postgres;

