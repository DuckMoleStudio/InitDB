create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_AsKML($1::ngpt.geometry, 15);
$$;

alter function st_askml(text) owner to postgres;

