CREATE RULE geometry_columns_delete AS
    ON DELETE TO ngpt.geometry_columns DO INSTEAD NOTHING;

