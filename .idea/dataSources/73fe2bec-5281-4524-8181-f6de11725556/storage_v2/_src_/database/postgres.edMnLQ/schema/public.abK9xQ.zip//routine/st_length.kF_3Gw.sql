create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ngpt.ST_Length($1::ngpt.geometry);
$$;

alter function st_length(text) owner to postgres;

