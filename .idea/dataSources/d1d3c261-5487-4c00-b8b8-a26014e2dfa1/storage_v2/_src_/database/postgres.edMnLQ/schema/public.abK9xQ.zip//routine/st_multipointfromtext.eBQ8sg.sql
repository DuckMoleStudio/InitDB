create function st_multipointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT ngpt.ST_MPointFromText($1)
$$;

alter function st_multipointfromtext(text) owner to postgres;

