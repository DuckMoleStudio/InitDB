create function overlaps_geog(ngpt.geography, ngpt.gidx) returns boolean
    immutable
    strict
    language sql
as
$$
SELECT $2 OPERATOR(ngpt.&&) $1;
$$;

alter function overlaps_geog(ngpt.geography, ngpt.gidx) owner to postgres;

