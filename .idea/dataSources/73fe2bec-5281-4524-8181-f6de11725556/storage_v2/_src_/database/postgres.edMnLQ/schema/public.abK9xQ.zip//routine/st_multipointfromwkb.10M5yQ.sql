create function st_multipointfromwkb(bytea) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
SELECT CASE WHEN ngpt.geometrytype(ngpt.ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN ngpt.ST_GeomFromWKB($1)
	ELSE NULL END
$$;

alter function st_multipointfromwkb(bytea) owner to postgres;

