create function st_distancesphere(geom1 ngpt.geometry, geom2 ngpt.geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
select ngpt.ST_distance( ngpt.geography($1), ngpt.geography($2),false)
$$;

comment on function st_distancesphere(ngpt.geometry, ngpt.geometry) is 'args: geomlonlatA, geomlonlatB - Returns minimum distance in meters between two lon/lat geometries using a spherical earth model.';

alter function st_distancesphere(ngpt.geometry, ngpt.geometry) owner to postgres;

