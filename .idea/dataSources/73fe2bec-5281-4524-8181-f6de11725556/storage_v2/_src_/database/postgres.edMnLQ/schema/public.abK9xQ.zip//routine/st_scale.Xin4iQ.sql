create function st_scale(ngpt.geometry, double precision, double precision) returns ngpt.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
SELECT ngpt.ST_Scale($1, $2, $3, 1)
$$;

comment on function st_scale(ngpt.geometry, double precision, double precision) is 'args: geomA, XFactor, YFactor - Scales a geometry by given factors.';

alter function st_scale(ngpt.geometry, double precision, double precision) owner to postgres;

